# Prompt for ChatGPT / Claude Code — implement Reflection Path in MindGymforallv1

Use the assets in this ZIP as the approved visual handoff. Inspect the existing MindGymforallv1 architecture before changing anything.

Implement a Reflection Room entered from the completed Story Lab journey. The transition should reveal the magical Reflection Path shown in the reference PNGs.

Each visible path brick must use `assets/bricks/reflection_brick_empty@4x.png` as a **text-free background**. Never bake child text into the PNG. Render the child's own short reflection label/affirmation as live UI text over the brick.

When the child enters the room, retrieve all saved reflections from that child's Story Lab/journal history, randomly sample up to 10 without replacement, and map one reflection to each visible brick. A brick remains mapped to the same reflection for that room visit. Tapping it opens/plays that reflection. On the next room visit, shuffle the visible sample so the journey feels fresh. Keep a separate `My Reflection Library` control for the complete scrollable archive so the child can always find every saved reflection.

Provide `Play one for me` for an immediate random reflection playback. During playback, use calm room music, narration of the saved reflection/affirmation, soft lantern/glow animation, and optional `Say it with me` / `Listen quietly` actions. Respect sound and reduced-motion settings.

Preserve both the child's original story and the new possible story. Never label the original story "wrong". The new story is another possibility or perspective.

Use existing app state, journal/session persistence, audio, routing, character components and animation libraries wherever possible. Do not create duplicate reward, audio or child-profile systems.

Use `IMPLEMENTATION_README.md` for data shape, path selection logic and safety details. The three files in `reference_scenes/` are the visual source of truth for layout, atmosphere and continuity.

After implementation report: files changed, persistence mapping, path sampling logic, reflection-library behavior, audio behavior, accessibility/reduced-motion support, and any unresolved issues.
