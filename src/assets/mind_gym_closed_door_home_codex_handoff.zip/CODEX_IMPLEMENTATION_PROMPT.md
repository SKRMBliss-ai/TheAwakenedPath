# CODEX IMPLEMENTATION PROMPT
## Mind Gym Home — Funny Feeling + My Good Choices Closed-Door Shelf

Implement the approved home design using this handoff.

READ FIRST:
- `README_START_HERE.md`
- `manifest.json`
- `approved_reference_closed_doors.png`
- `interaction_reference_open_rooms.png`
- all `reference_crops/`
- inspect the current repository before modifying anything

The approved CLOSED-DOOR image is the source of truth for the default home state.

Do not redesign it into cards, a dashboard, tabs or a conventional menu.

==================================================
1. CHARACTER CONTINUITY — CRITICAL
==================================================

Use the EXISTING usual Mind Gym boy already used on the old/current home page.

Do not generate, redraw or substitute another boy.

Match:
- same face
- same proportions
- same red cap
- same white shirt
- same dark shorts
- same blue/yellow shoes
- same backpack
- same character scale and camera style

Use the existing Chirpy asset and place Chirpy with/on the boy as already established.

If the repo already contains higher-quality canonical boy/Chirpy assets, prefer those over the PNG crops in this bundle.

==================================================
2. HOME COMPOSITION
==================================================

Desktop/tablet:

LEFT ~35%
Funny Feeling? glowing blue magical entry.

CENTER ~20–25%
boy + Chirpy, visually bridging the two journeys.

RIGHT ~40–45%
My Good Choices wooden room shelf.

Preserve the warm magical treehouse environment.

Do not overcrowd the screen.

==================================================
3. LEFT FLOW — FUNNY FEELING
==================================================

Keep the left side visually close to:
`approved_reference_closed_doors.png`

Title:
FUNNY FEELING?

Subtitle:
Step into your mind.

The left path represents:
1. Feeling
2. Body
3. Thought
4. What happened?
5. Story
6. Another way to see it

Use the existing journey implementation from the current product.

Do not rebuild the full flow on the home page.
This side is an inviting visual preview / entry point.

Primary CTA:
Start My Journey

==================================================
4. RIGHT FLOW — MY GOOD CHOICES
==================================================

Title:
MY GOOD CHOICES

Subtitle:
Small choices. Big growth. A brighter you.

The shelf contains exactly these seven rooms:

1. Be Kind
2. Tell the Truth
3. Make Good Choices
4. Include Everyone
5. Take Care of My Body
6. Help Others
7. Mind & Heart Time

At rest, ALL seven room doors are CLOSED.

This resting state should look like:
`approved_reference_closed_doors.png`

The shelf should feel architectural:
- wooden shelves
- vines
- flowers
- little lanterns
- glowing category signage
- small category symbol on each door
- dimensional inset doors
- tiny star/keyhole details

Do not make them look like ordinary rectangular app cards.

==================================================
5. CLOSED → HOVER → OPEN INTERACTION
==================================================

This interaction is central.

Each room has these UI states:

CLOSED
HOVER / FOCUS
OPEN PREVIEW
ACTIVE / ENTERED

--------------------------------
CLOSED
--------------------------------

Default state:
- wooden door shut
- room title visible above/on door
- category symbol visible
- low warm internal glow leaking subtly around door edges
- small star/keyhole idle glow
- no Play/Learn content visible
- no large question panel visible

--------------------------------
HOVER / KEYBOARD FOCUS
--------------------------------

On pointer hover OR keyboard focus:

0–150ms:
- sign brightens slightly
- category symbol gains glow
- tiny spark travels around frame

150–300ms:
- handle/star/keyhole illuminates
- door shifts forward 2–4px

300–600ms:
- wooden door rotates open approximately 20–35 degrees
- warm interior light spills onto shelf
- illustrated room becomes partially visible

600–850ms:
- room opens enough to reveal its compact question/prompt
- Play and Learn controls fade/slide in

Do not instantly swap images.
The door must feel like a physical door opening.

--------------------------------
OPEN PREVIEW
--------------------------------

Use `interaction_reference_open_rooms.png` as the interaction-state guide.

An open room should reveal:
- miniature illustrated environment
- ONE short prompt
- Play
- Learn

Example:

BE KIND
“What could you do today to be kind?”

[ Play ]
[ Learn ]

Keep content concise.

Only ONE room may be open at a time.

When another room opens:
- current room closes
- new room opens

--------------------------------
POINTER LEAVE
--------------------------------

If opened only through hover:
- wait ~200–300ms
- close gently when pointer leaves the interactive room region

If the user CLICKED to pin/open:
- keep it open until:
  - another room is selected
  - close/back is selected
  - user enters Play/Learn

This avoids frustrating hover flicker.

==================================================
6. TOUCH / MOBILE INTERACTION
==================================================

There is no hover on mobile.

Use:

FIRST TAP:
opens the door and reveals preview.

SECOND TAP:
child chooses Play or Learn.

TAPPING ANOTHER ROOM:
closes previous room and opens the new room.

Do not immediately launch the activity on first tap.

==================================================
7. ROOM CONTENT
==================================================

Each room should have its own compact invitation.

Use child-friendly examples such as:

BE KIND
“What kind thing could you do today?”

TELL THE TRUTH
“What happens when we tell the truth?”

MAKE GOOD CHOICES
“Which choice helps you and others?”

INCLUDE EVERYONE
“How can you include someone today?”

TAKE CARE OF MY BODY
“What helps your body and mind feel good?”

HELP OTHERS
“Who could you help today?”

MIND & HEART TIME
“Want a quiet moment to breathe or reflect?”

These prompts are content, not fixed art.

Render them in code.

==================================================
8. PLAY / LEARN
==================================================

Every Good Choices room offers two paths.

PLAY
- mini-game
- practice scenario
- interactive choice
- short challenge
- role-play style scene

LEARN
- short explanation
- tiny visual story
- example
- age-appropriate principle

Do not create a full separate room route just to expose the Play/Learn controls.

The preview appears inside the shelf room first.

==================================================
9. ANIMATION STYLE
==================================================

Use premium restrained cinematic motion.

Good:
- door hinge rotation
- light spill
- tiny floating fireflies
- lantern flicker
- subtle parallax
- sign glow
- Chirpy glance/reaction
- light dust
- gentle scale

Avoid:
- confetti
- bouncing every object
- fast zooms
- large particle explosions
- constant pulsing

Respect `prefers-reduced-motion`.

==================================================
10. POINTS / MONTH
==================================================

Keep the compact top-right progress area.

Show:
- current points
- current month / monthly activity indicator

These are secondary.

They must not compete visually with the two main flows.

Use real dynamic data if the existing app already has it.

==================================================
11. MOBILE HOME
==================================================

DO NOT shrink the full desktop shelf into an unreadable phone screen.

Mobile landing should primarily show TWO destinations:

Funny Feeling?
My Good Choices

Use the boy + Chirpy between or just below them when space allows.

When the child enters My Good Choices:
show the room shelf as a focused mobile scene.

Possible mobile shelf:
- 2-column room-door grid
- large closed doors
- only room names/symbols visible at rest
- tap opens one door inline
- remaining rooms dim slightly
- scroll naturally

Do not show all prompts at once.

==================================================
12. ACCESSIBILITY
==================================================

Every room must be a semantic interactive control.

Keyboard:
- Tab focuses each room
- Enter/Space opens it
- Escape closes an open preview

Focus must trigger the same meaningful state as hover.

Use:
- visible focus ring integrated into magical glow
- accessible label:
  “Be Kind room. Press Enter to preview.”
- buttons for Play and Learn
- no critical information available only on hover

==================================================
13. ASSET STRATEGY
==================================================

Use:
`production_assets/background_environment.png`
for the environment when useful.

Use canonical repo assets first for:
- boy
- Chirpy
- logo

Use production PNGs in this package for:
- visual matching
- room art
- category signage
- buttons
- badges
- Feelings visual language

Use reference crops to match exact:
- proportions
- shelf layout
- door shape
- open/closed visual state
- spacing
- glow intensity

IMPORTANT:
Do NOT implement the whole screen as one screenshot background with fake click hotspots.

The experience must remain layered and responsive.

==================================================
14. SUGGESTED COMPONENTS
==================================================

Adapt naming to the repo:

MindGymHome
FunnyFeelingEntry
GoodChoicesShelf
GoodChoiceRoom
GoodChoiceDoor
GoodChoiceRoomPreview
GoodChoiceRoomInterior
HomeCharacterStage
ProgressBadges

Suggested room state:

type GoodChoiceRoomState =
  | "closed"
  | "hover"
  | "open"
  | "active";

Store:
activeGoodChoiceRoomId: string | null
pinnedGoodChoiceRoomId: string | null

==================================================
15. REPOSITORY INTEGRATION
==================================================

Before coding inspect:
- current home component
- existing usual boy asset
- Chirpy asset
- points state
- diary/month state
- Good Choices categories/data
- route architecture
- existing room/game components
- CSS/animation framework
- responsive breakpoints
- accessibility helpers

Reuse existing systems.

Do not duplicate data or create alternate versions of the boy/Chirpy.

==================================================
16. ACCEPTANCE CRITERIA
==================================================

Implementation is complete when:

- default home visually matches the approved closed-door reference
- usual existing Mind Gym boy is used
- Chirpy is with the boy
- left Funny Feeling entry remains prominent
- right My Good Choices uses seven closed wooden room doors
- no room content is exposed before interaction
- desktop hover opens a door smoothly
- keyboard focus can open the same preview
- touch first-tap opens preview
- only one room is open at a time
- open room reveals one short question + Play + Learn
- closing/opening transitions feel physical
- points/month remain secondary
- mobile shows two clear main destinations before revealing detailed shelf content
- semantic accessibility works
- reduced motion works
- no full-screen screenshot hack is used
- typecheck passes
- lint passes
- tests pass
- production build passes

After implementation report:
1. files changed
2. assets used
3. existing canonical boy/Chirpy assets reused
4. components added/reused
5. hover/focus/touch door state logic
6. animation implementation
7. responsive behaviour
8. accessibility behaviour
9. test/build results
10. anything intentionally unchanged
