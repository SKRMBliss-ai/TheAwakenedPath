Mind Gym — My Good Choices room doors asset pack

Included PNG assets:
1. Be Kind
2. Tell the Truth
3. Make Good Choices
4. Include Everyone
5. Take Care of My Body
6. Help Others
7. Mind & Heart Time (slightly open door with light)

All assets are high-quality room-door UI concepts matching the whimsical Mind Gym style.
