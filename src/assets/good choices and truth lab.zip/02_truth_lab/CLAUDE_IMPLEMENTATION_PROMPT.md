# Claude Code implementation prompt — Truth Lab screen

Implement the approved **Truth Lab** screen using the attached handoff assets.

## Do not redesign the concept
Keep:
- magical cozy wooden room
- large left-side door with glowing golden star handle
- hanging **Truth Lab** sign
- Chirpy as the guide
- five bright rounded thinking cards stacked vertically on the right
- warm lantern lighting, purple/gold/teal palette
- soft Pixar-like child-friendly 3D feel

## Screen purpose
Truth Lab helps a child re-examine what really happened in a situation.

Use the five-step guided structure:
1. **HE FEELS**
2. **IT SITS**
3. **HIS MIND SAID**
4. **WHAT ACTUALLY HAPPENED**
5. **YOU SAID**

The screen should feel like a reflective mini-journey, not a form.

## Layout
### Top
- back button
- Mind Gym logo
- talk to a grown-up button

### Left
- large magical wooden door
- glowing star handle
- Truth Lab sign
- decorative book stack, lantern, plant, rug

### Right
- vertical stack of five rounded cards
- each card has:
  - icon
  - title
  - short text/example
  - small expressive boy illustration/portrait on the right
- below the cards, Chirpy speaks in a supportive dialogue bubble
- optional smaller subtext line below the bubble

## Behaviour
- cards can animate in sequence
- selecting/advancing to the next step should slightly highlight that step
- content should be dynamic and data-driven, not hardcoded to this one example
- Chirpy’s supportive message should update based on the child’s inputs
- maintain a calm, non-judgmental tone

## Asset usage
Use:
- `production_assets/background_environment.png`
- `door_with_magical_handle.png`
- `truth_lab_sign.png`
- `chirpy.png`
- step card assets as visual reference/components
- `supportive_dialogue_block.png` as layout/styling reference
- decorative assets as needed

Use `approved_reference_truth_lab.png` and the `reference_crops/` folder for fidelity.

Important: rebuild all actual interactive copy, step text, dynamic content, and stateful behaviour in code rather than relying on baked image text.
