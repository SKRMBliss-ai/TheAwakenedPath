# Mind Gym – Home / Feelings / Good Choices Asset Handoff

This package is prepared from the approved home concept.

## Main structure

### Left: Funny Feeling?
A single connected **Feelings Room** journey:
1. Feeling
2. Body
3. Thought
4. What happened?
5. Story
6. Another way to see it

Do not create separate rooms for those steps. The child answers one step and the world flows naturally into the next.

### Right: My Good Choices
A magical shelf of seven room doors:
- Be Kind
- Tell the Truth
- Make Good Choices
- Include Everyone
- Take Care of My Body
- Help Others
- Mind & Heart Time

Each room should be clickable. Opening a room should reveal a compact panel/card with:
- one simple daily reflection/question
- child-friendly choices
- **Play** to practise through a mini-game/activity
- **Learn** to understand the idea through a short story/experience

## Monthly diary
Good-choice answers and points should be stored against the selected month.
Children should be able to move backward to previous months and review past records.

## Recommended implementation
Use `background_environment.png` as the scene base.
Place the character, Feelings Room and Good Choices shelf as independent layers.
Keep all real text, controls, counters, hover states and animations in HTML/CSS/React rather than as baked image text.

The `reference_crops/` folder contains exact visual crops from the approved reference image.
The `production_assets/` folder contains cleaner implementation assets.
