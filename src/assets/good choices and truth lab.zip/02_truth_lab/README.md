# Truth Lab – Asset Handoff

This package is based on the approved Truth Lab UI screen.

## Purpose
Truth Lab helps the child unpack a difficult moment by moving through a guided sequence:

1. **He feels** — emotion label
2. **It sits** — where/how it shows up in the body
3. **His mind said** — the story or thought
4. **What actually happened** — the facts
5. **You said** — a more grounded alternative response

Then Chirpy offers a supportive reflection.

## Main sections
- Back button + Mind Gym logo
- Talk to a grown-up button
- Magical door with glowing handle
- Truth Lab sign
- Five stacked conversation cards
- Chirpy supportive dialogue block
- Cozy room decor/background

## Implementation guidance
Use the clean background as the base scene and rebuild the real UI in code:
- card text
- dynamic examples
- hover/focus/selected states
- step progression
- dialogue content
- accessibility and navigation

The `reference_crops/` folder contains direct crops from the approved screen for fidelity.
The `production_assets/` folder contains cleaner separated assets for implementation.
