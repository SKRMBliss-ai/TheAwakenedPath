# Claude Code — implement the Mind Gym Games Room

You are implementing the children's **Games Room** in the existing Mind Gym codebase. Use the supplied PNG assets and references in this ZIP. Do not rebuild it as a questionnaire or a stack of cards. The room is a persistent magical place; only the challenge/theme inside it changes.

## Product intent

The child enters from a **feeling door**. The destination is always named **Games Room**. Under that title, show one active practice theme chosen from:

- Be Kind
- Be Honest
- Say Good Things
- Include Everyone
- Take Care of My Body
- Help Others

The active theme should be influenced by the feeling door the child came through. Reuse any existing route/session state already representing the source feeling. If the repo already has a door→practice mapping, preserve it. If it does not, use `config/games_room_theme_map.json` only as a starter affinity map, not a clinical rule.

## Core experience

The Games Room is one continuous scene. Do NOT replace every question with a new full screen.

1. Enter Games Room from a feeling door.
2. Room title stays fixed: **Games Room**.
3. Active theme ribbon changes below/near the title.
4. Chirpy introduces a short real-life scenario in a speech bubble / hanging board.
5. Three magical treasure choices appear in-world on the rug.
6. Child taps a treasure. It opens with a short burst of sparkles and a tiny visual consequence/animation.
7. Chirpy responds warmly. Avoid “wrong!” or red failure states. For an unhelpful choice, use language like “What else could you try?” and let the child explore another chest.
8. Award a **practice star** for completing/reflection, not for moral worth. Do not imply the child is “good” because they chose the expected answer.
9. Progress is shown as five small stars/paw marks, then a treasure celebration after the short run.
10. Offer “Play again” / another scenario so the room becomes replayable.

## Visual layout

Use `references/games_room_theme_system_concept.png` as the primary visual target.

- warm, magical timber games room/treehouse
- boy seated on the left
- Chirpy near the boy / choices
- large central hanging challenge board
- three treasure chests across the lower center
- progress immediately below the challenge
- Mind Stars at upper right
- Leave Room and Sound controls at upper left
- small, persistent “Talk to a grown-up” affordance should remain available according to the app's existing safety UI
- theme ribbon is secondary to “Games Room”, never the page title

Do not add a dashboard, tabs-heavy settings UI, or card grid over the room.

## Assets

Use assets from `/assets` exactly where practical:

- `boy_sitting.png` — recurring child reference
- `chirpy_happy.png` — Chirpy companion
- `room_title_games_room.png` — Games Room sign reference/asset
- `subtitle_be_kind.png`
- `subtitle_be_honest.png`
- `subtitle_say_good_things.png`
- `subtitle_include_everyone.png`
- `subtitle_take_care_my_body.png`
- `subtitle_help_others.png`
- `chest_laugh.png`
- `chest_continue.png`
- `chest_encourage.png` — use as the third/kind-response chest; filename may be aliased in code to `chest_kind`
- `speech_bubble.png`
- `star_filled.png`
- `star_empty.png`
- `sparkles.png`
- `celebration_stars.png`
- `reward_chest_open.png`
- `chalkboard.png`
- `books_stack.png`
- `rug.png`
- `cushions.png`
- `plant_sprout.png`
- `good_choices_sign.png`
- `bottom_prompt.png`

The reference images are design targets, not sprites.

## Theme content rules

### Be Kind
Use friendship, encouragement, sharing, patience, noticing embarrassment, welcoming, and small helpful gestures.

### Be Honest
Use child-safe situations such as admitting a mistake, saying “I don't know,” returning something, correcting an exaggeration, or asking a grown-up for help. Never use shame or interrogation.

### Say Good Things
Frame positively: respectful words, helpful tone, encouraging someone, choosing not to repeat hurtful words, and repairing after speaking unkindly. Quietly filter profanity, slurs, sexual/explicit material, and harmful/degrading acts. **Do not mention those categories to the child** and do not create “forbidden word” curiosity loops.

### Include Everyone
Use playground/class/group moments, invitations, taking turns, noticing someone alone, accommodating differences, and making space without forcing friendship.

### Take Care of My Body
Use joyful movement, sleep/rest, water, hygiene, outdoor play, and varied foods that help the body grow and have energy. Do **not** label foods “bad” or “junk”, do not discuss weight/calories, and do not reward restriction. A child can choose a nourishing option without being shamed for treats.

### Help Others
Use safe, realistic helping: pick something up, get a grown-up, comfort someone, share instructions, help a younger child, or ask before helping. Never encourage risky rescuing or taking responsibility for adult problems.

## Feeling-door continuity

Read the source feeling from the existing session/route. The feeling should affect:

- which themes are favoured
- scenario tone and difficulty
- ambient room accents (subtle lighting/particles only)
- Chirpy's opening line

It must **not** label the child or imply that a feeling determines what kind of person they are.

Example behavior:
- sad/left-out doorway → more Include Everyone / Help Others scenarios
- angry/frustrated doorway → more Be Honest / Say Good Things / Be Kind repair scenarios
- worried doorway → more Be Honest / Take Care of My Body / Help Others scenarios
- happy/excited doorway → more Be Kind / Help Others / Say Good Things scenarios

Keep this configurable and overrideable by content metadata.

## Interaction states

Implement reusable state machine rather than separate pages:

`entering -> intro -> challenge -> choosing -> reveal -> reflection -> reward -> nextChallenge -> complete`

The room remains mounted while the state changes. Animate only the in-world objects and overlays.

### Choice motion
- idle chests: slow 2–4 px float / soft glow
- hover/focus: ~1.04 scale, brighter rim, tiny sparkle
- select: chest lid pops, 250–400 ms anticipation, then reveal
- never use frantic motion
- support `prefers-reduced-motion`

### Feedback
Helpful/expected choice: warm affirmation + show what happens in the tiny scene.
Alternative/unhelpful choice: neutral curiosity, e.g. “Hmm… what might happen next?” then permit retry or continue to reflection. No red X, buzzer, shame, or loss of stars.

## Replayability

Do not simply show question 2 after question 1. Use micro-transitions in the same room:

- challenge board flips/rolls to the next card
- chest icons magically swap
- one shelf object changes after each challenge
- Chirpy hops/flys to a new perch
- progress star lights up
- after 5, reward chest opens and a collectible room decoration can appear

Rotate scenarios: avoid the last two, favour untried content, respect age band and session length.

## Quiet / distressed state

If the app's existing safety state indicates high distress, **do not run the Games Room challenge loop**. Reduce ambient motion, shorten copy, show no clever trapdoors, keep trusted-adult access prominent, and route to the existing calm/safety experience.

## Accessibility

- all choices keyboard/focus navigable
- minimum touch target 44 px; use larger targets for young children
- narration/audio button for scenario text
- do not rely on color alone
- captions for speech and sound-dependent cues
- `aria-label` for icon-only buttons
- preserve focus when board content changes

## Technical implementation

First inspect the repo and identify the existing:

- router / feeling-door route state
- child/session store
- Mind Stars/reward store
- audio system
- safety/quiet-state signal
- component conventions and styling system

Then implement with the repo's existing framework; do not introduce a second styling or state-management stack.

Suggested components (adapt names to repo):

- `GamesRoomScene`
- `GamesRoomHeader`
- `ThemeRibbon`
- `ChallengeBoard`
- `TreasureChoice`
- `ChirpyGuide`
- `PracticeProgress`
- `RewardReveal`
- `GamesRoomSafetyActions`

Suggested data shape:

```ts
type GamesRoomTheme =
  | 'be_kind'
  | 'be_honest'
  | 'say_good_things'
  | 'include_everyone'
  | 'take_care_my_body'
  | 'help_others';

type GamesRoomScenario = {
  id: string;
  theme: GamesRoomTheme;
  ageBands: Array<'3-8' | '9-14'>;
  feelingAffinity?: string[];
  prompt: string;
  choices: Array<{
    id: string;
    label: string;
    iconAsset?: string;
    consequence: string;
    reflectionPrompt?: string;
  }>;
};
```

Keep content in data files so scenarios can scale without bespoke screens.

## Acceptance criteria

- The screen title is always “Games Room”.
- Theme subtitle changes based on feeling-door/session context.
- All six themes are implemented and data-driven.
- At least 3 scenarios per theme are provided as seed content, age-safe and non-shaming.
- Three in-world treasure choices, not three flat answer cards.
- The room does not remount between questions.
- Choice produces an animated consequence before feedback.
- No moral score, no red failure state, no weight/diet scoring, no explicit/sexual/profanity content.
- Quiet state bypasses gameplay.
- Replay avoids the previous two scenarios.
- Works on tablet and mobile landscape/portrait with responsive composition.
- Uses the supplied assets and visually matches the provided reference.

## Final verification

Run the app, test at least one route from each available feeling door, verify theme affinity changes, verify all six theme ribbons, keyboard navigation, reduced motion, audio control, quiet-state bypass, progress persistence, and replay behavior. Fix visual regressions before finishing.
