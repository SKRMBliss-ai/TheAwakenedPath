Story room asset bundle for app implementation. Includes isolated transparent PNG assets derived from the approved Story screen plus the original reference screen.
