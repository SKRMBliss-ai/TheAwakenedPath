# Claude Code implementation prompt — Mind Gym approved two-flow home

Implement the attached approved Mind Gym visual direction using the assets in this handoff package.

## Do not redesign the concept
The approved visual structure is:
- magical treehouse / mind-world environment
- same boy character in the centre
- Chirpy on/near his shoulder
- left = **Funny Feeling?**
- right = **My Good Choices**
- no door knobs
- no Big Feelings room
- do not turn the experience into a conventional dashboard

## Flow A — Funny Feeling?
This is ONE connected Feelings Room, not multiple rooms.

The child progresses through:
1. Feeling — “What are you feeling?”
2. Body — “What do you notice in your body?”
3. Thought — “What’s going through your mind?”
4. What happened? — capture the situation/event
5. Story — show the story the mind made
6. Another way to see it — offer/collect another possible perspective

Each answer should animate the child naturally to the next step inside the same room/world.
Do not create a separate Reflection step on the home journey.
Keep skip / “I don’t know” / stop available where appropriate.

## Flow B — My Good Choices
Use the right-side shelf architecture.

Create seven clickable room doors:
1. Be Kind
2. Tell the Truth
3. Make Good Choices
4. Include Everyone
5. Take Care of My Body
6. Help Others
7. Mind & Heart Time

The shelf should stay visible and magical, with small animated door/window rooms rather than flat cards.

### Room behaviour
When a child taps a room:
- the little door opens
- the room glows/zooms slightly
- a compact panel unfolds from the room
- ask one child-friendly reflection question
- allow simple choices and optional short text/voice
- show two clear paths:
  - **Play** — practise through an age-appropriate mini-game
  - **Learn** — short story, explanation or guided experience
- award/display today’s points without ranking or judging the child

Do not make seven new full-screen menu pages unless technically unavoidable.

## Monthly Good Choices Diary
Store all diary responses by date and month.

Add:
- current month selector
- today’s points
- a monthly progress indicator
- ability to go back to previous months
- read past month records
- monthly “Look Back & Learn” reflection:
  - What did I learn about myself this month?
  - What made me feel proud?
  - What was difficult? What can I do next time?
  - What are my goals for next month?

Do not use emotional-health scores or moral rankings.

## Asset usage
Use `production_assets/background_environment.png` for the environment base.
Layer:
- `boy_fullbody.png`
- `chirpy.png`
- `feelings_room.png`
- `good_choices_room.png`
- category sign assets/icons as needed

Use `approved_reference_home.png` and the `reference_crops/` folder as visual fidelity references.

Important: rebuild labels, buttons, counters, speech bubbles and interactive text in code for responsiveness and accessibility; do not rely on text baked into PNGs.

## Responsive
Desktop/tablet:
- Feelings world left
- boy centred
- Good Choices shelf right

Mobile:
- show only TWO large room destinations first: Funny Feeling? and My Good Choices
- keep the boy between/under them as space permits
- do not show every step/category on the initial mobile home screen
- after entering a destination, reveal its internal content

## Motion
Use subtle cinematic motion:
- gentle lantern flicker
- tiny fireflies/sparkles
- room glow on hover/focus
- doors physically open
- selected room moves slightly forward
- Chirpy reacts softly
- no chaotic particle effects

Preserve the existing project architecture, child safety flow, trusted grown-up access and data layer.
