# CLAUDE MASTER IMPLEMENTATION PROMPT
## Mind Gym — My Inner Diary + Truth Lab

Implement these two approved Mind Gym screens from the attached handoff package.

Read first:
- `README_START_HERE.md`
- `MASTER_MANIFEST.json`
- each screen's own `CLAUDE_IMPLEMENTATION_PROMPT.md`
- each screen's approved reference PNG

Do not redesign either screen. The approved references are the visual source of truth.

---

# SCREEN 1 — MY INNER DIARY

Folder:
`01_my_inner_diary/`

Purpose:
A magical monthly diary / Good Choices reflection space.

Required behaviour:
- selected month/year
- month navigation backward and forward
- store all diary activity by calendar date
- seven category rows:
  1. Be Kind
  2. Tell the Truth
  3. Make Good Choices
  4. Include Everyone
  5. Take Care of My Body
  6. Help Others
  7. Mind & Heart Time
- display daily marks/dots and category totals
- tapping a day lets the child review or add that day's activity
- preserve past months and allow read-back
- four end-of-month reflections:
  - What did I learn about myself this month?
  - What made me feel proud?
  - What was difficult? What can I do next time?
  - What are my goals for next month?
- support partially completed months
- Save This Month action

Interaction feel:
A magical storybook diary room, not a spreadsheet even though the monthly grid is structured.

Implementation:
Use the clean background and decorative PNGs as art layers.
Build the grid, text, textarea inputs, month logic, selected states and persistence in code.

---

# SCREEN 2 — TRUTH LAB

Folder:
`02_truth_lab/`

Purpose:
A guided room that helps the child separate feeling/body/thought/story from what actually happened.

Required five-card sequence:
1. HE FEELS
2. IT SITS
3. HIS MIND SAID
4. WHAT ACTUALLY HAPPENED
5. YOU SAID

Required behaviour:
- sequence is data-driven and reusable for different situations
- cards can animate in progressively
- selected/current step is gently highlighted
- child content is never judged as correct/wrong
- Chirpy's supportive dialogue updates from the session state
- trusted-grown-up access stays visible
- child can stop or go back

Interaction feel:
One coherent room, not five disconnected forms.
The cards should feel like pieces of the child's story assembling in front of them.

Implementation:
Use the approved background, door, sign, Chirpy and decorative assets as art layers.
Build actual card copy, dynamic text and interaction states in code.

---

# SHARED VISUAL CONTINUITY

Both screens must clearly belong to the same Mind Gym universe:
- warm magical wood architecture
- soft cinematic lantern light
- deep violet / purple + warm gold + gentle teal/pink accents
- rounded child-friendly shapes
- soft glows rather than harsh neon
- same rendering language for plants, books, lamps, furniture and magical details
- same typography system as the existing app
- subtle fireflies / sparkles only where useful
- no visually noisy particles

Do not invent new franchise characters.
Use the existing Mind Gym characters/companions already present in the project wherever equivalent assets exist.

---

# RESPONSIVE / ACCESSIBILITY

Desktop/tablet:
follow approved composition closely.

Mobile:
- preserve hierarchy, but stack rather than shrink illegibly
- keep large tap targets
- diary month selector should horizontally scroll or collapse gracefully
- Truth Lab cards may become a single vertical stack
- trusted-grown-up access remains reachable
- do not hide essential stop/back navigation

All semantic text should be rendered in code for screen readers and localization.

---

# ENGINEERING EXPECTATIONS

Before editing:
1. inspect current routing
2. inspect design tokens/theme
3. inspect existing child/Chirpy assets
4. inspect persistence/data model
5. inspect voice input if available
6. inspect animation system
7. inspect safeguarding / grown-up access
8. identify reusable components before adding new ones

Do not duplicate existing infrastructure.

Suggested data models may differ from the current repo; adapt to the project's conventions.

After implementation:
- run typecheck
- run lint
- run tests
- run production build
- fix regressions caused by the change

Finally report:
1. files changed
2. components created
3. state/data changes
4. persistence changes
5. animation changes
6. responsive changes
7. anything intentionally left unchanged
