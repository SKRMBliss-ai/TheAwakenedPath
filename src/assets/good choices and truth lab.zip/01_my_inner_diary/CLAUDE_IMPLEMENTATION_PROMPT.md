# Claude Code implementation prompt — My Inner Diary monthly screen

Implement the attached approved **My Inner Diary** monthly reflection page.

## Do not redesign the concept
Keep the visual direction:
- magical cozy treehouse / diary room
- open storybook header
- soft purple / gold / cream palette
- whimsical Disney/Pixar-inspired children’s app style
- warm lantern light, soft plants, gentle magic, comforting bedtime feeling

## Screen purpose
This is the monthly diary page reached from the child's diary flow.
It should let the child:
- browse months
- see which good choices they logged across the month
- review totals by category
- reflect on the month
- save the month
- revisit past months later

## Main layout
### Header
- back button (“Back to Mind Gym”)
- main open-book title: **My Inner Diary**
- selected month shown prominently, e.g. **September 2026**
- month tabs to browse past months (e.g. Sep 2026, Aug 2026, Jul 2026, Jun 2026)
- left/right month navigation arrows

### Monthly tracker
Show a large rounded panel with:
- day numbers across the top
- seven category rows
- colored dots for saved activity on a given day
- totals at right
- ability to tap a day to add/open a saved good choice or practice

Diary categories:
1. Be Kind
2. Tell the Truth
3. Make Good Choices
4. Include Everyone
5. Take Care of My Body
6. Help Others
7. Mind & Heart Time

### Reflection section
A **Look Back & Learn** section with four prompts:
- What did I learn about myself this month?
- What made me feel proud?
- What was difficult? What can I do next time?
- What are my goals for next month?

Each should support text input and optional voice input if the app already has voice support.

### Bottom values
Show the value chips:
- Be kind to yourself
- Listen to your heart
- Do your best
- Learn from mistakes
- Be grateful always
- Everyone is my teacher
- I create my own path

### Primary CTA
Large **Save This Month** button.

## Data / behaviour
- Store diary data by month and year.
- Child must be able to revisit previous months and read past records.
- Tapping a dot/day should open that day’s saved choice(s) or let the child create one.
- Support partially completed months.
- Preserve accessibility and clear tap targets.

## Asset usage
Use:
- `production_assets/background_environment.png` for the clean scene base
- `header_book_title.png`
- `month_selector_tabs.png`
- `monthly_grid_panel.png`
- `look_back_learn_header.png`
- `reflection_prompt_cards.png`
- `value_chips.png`
- `save_this_month_button.png`
- decorative assets as needed

Use the `approved_reference_diary.png` and `reference_crops/` folder for exact style guidance.

Important: rebuild all actual text, inputs, tracker dots, month navigation and form states in code rather than relying on baked PNG text.
