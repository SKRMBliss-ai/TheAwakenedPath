# Mind Gym — Games Room Asset Pack v2

This pack turns the current question-by-question “Be Kind” screen into a reusable **Games Room**.

The room name stays fixed. The practice theme changes with feeling-door context:
**Be Kind · Be Honest · Say Good Things · Include Everyone · Take Care of My Body · Help Others**.

## Folders

- `assets/` — transparent PNG elements for implementation
- `references/` — full-scene design references and the current app screen
- `config/` — starter theme/door affinity mapping
- `CLAUDE_IMPLEMENTATION_PROMPT.md` — paste this into Claude Code with the ZIP/repo

## Important product behavior

This should feel like play inside one magical place, not a quiz that loads a new screen after every answer. The challenge board, treasure chests, Chirpy, progress, effects, and small room details change while the room remains continuous.

For “Take Care of My Body”, use positive health habits (movement, rest, water, hygiene, varied nourishing foods) rather than “good/bad food”, weight, calorie, or restriction language.

For “Say Good Things”, keep child-facing language positive and quietly exclude explicit, sexual, profane, slur-based, degrading, or harmful content without drawing attention to those categories.
