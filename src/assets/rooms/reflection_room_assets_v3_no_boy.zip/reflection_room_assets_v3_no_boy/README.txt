MIND GYM — REFLECTION ROOM ASSET PACK v3 (NO BOY)

Important:
- The boy/child asset is intentionally NOT included.
- Use the app's existing locked boy + Chirpy-on-back asset.
- All personalized copy, feelings, thoughts, journey counts and affirmations should be rendered from the database in code, not baked into PNGs.
- Files 06–09 are visual references for styling/layout. Prefer files 02–03 as reusable blank surfaces for dynamic content.

ASSETS
01_reflection_room_background.png — environment/background, no child
02_blank_glass_panel_star.png — transparent reusable magical glass panel
03_blank_glass_panel_heart.png — transparent reusable magical glass panel
04_star_lantern.png — transparent decor
05_crystal_books_garden_vignette.png — transparent decor
06_reflection_card_reference.png — reference treatment for reflection detail popup
07_monthly_journey_panel_reference.png — reference treatment for monthly insight popup
08_thought_constellation_reference.png — reference treatment for thought pattern popup
09_compact_story_audio_reference.png — reference for compact audio treatment; DO NOT build a long player bar
10_full_scene_reference.png — overall composition/reference only
