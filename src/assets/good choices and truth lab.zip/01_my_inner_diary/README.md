# My Inner Diary – Monthly Reflection Handoff

This package is prepared from the approved **My Inner Diary** monthly screen.

## What this screen is
A monthly diary / reflection page where the child can:
- track small good choices day by day
- view category totals
- switch between months
- look back and learn at the end of the month
- save the month and review previous months later

## Seven diary categories
- Be Kind
- Tell the Truth
- Make Good Choices
- Include Everyone
- Take Care of My Body
- Help Others
- Mind & Heart Time

## Main UI sections
1. Open-book title header (`My Inner Diary` + current month)
2. Month selector tabs
3. Monthly dot-grid tracker
4. Four `Look Back & Learn` reflection prompts
5. Bottom value chips
6. `Save This Month` primary CTA
7. Cozy decorative environment elements

## Implementation guidance
Use the clean background image as the scene base and build the actual interactive UI in code:
- day numbers
- tracker dots
- category totals
- month switching
- text areas
- save states
- hover/focus states
- validation and persistence

The `reference_crops/` folder contains exact visual crops from the approved concept for fidelity.
The `production_assets/` folder contains cleaner separated assets.
