# Mind Gym — Combined Claude-Ready Handoff

This ZIP combines the two approved screens requested:

## 1. My Inner Diary
A monthly Good Choices / reflection space with:
- seven diary categories
- day-by-day monthly tracker
- category totals
- past-month navigation
- four `Look Back & Learn` prompts
- `Save This Month`
- warm magical diary-room environment

Folder: `01_my_inner_diary/`

## 2. Truth Lab
A guided reflective room with:
- magical Truth Lab door/sign
- five connected thinking cards
- Chirpy supportive dialogue
- fact-versus-story reflection
- warm magical room environment

Folder: `02_truth_lab/`

## What each screen folder contains
- `production_assets/` — separated PNG implementation assets
- `reference_crops/` — exact crops from the approved design
- clean background
- full asset sheet
- approved reference
- per-screen manifest
- detailed Claude implementation prompt
- README

## Use with Claude Code
Start with `CLAUDE_MASTER_IMPLEMENTATION_PROMPT.md`, then give Claude both screen folders.

Important:
- The approved references are the source of truth.
- Rebuild interactive copy and controls in code.
- Treat the PNGs as art layers and fidelity references.
- Keep one coherent Mind Gym visual universe across both screens.
