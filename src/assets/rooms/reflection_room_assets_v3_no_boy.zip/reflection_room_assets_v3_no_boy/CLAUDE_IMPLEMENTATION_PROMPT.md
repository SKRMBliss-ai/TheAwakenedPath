# Claude Code implementation prompt — Mind Gym Reflection Room v3

Implement a single integrated **Reflection Room** experience using the supplied asset pack. Do not create a separate Play & Relax screen. The Reflection Room itself is the calm place where the child revisits reflections, listens to personalised affirmations, and gently explores their journey history.

## Non-negotiable product direction

This is not a dashboard-first app and not a form. It is a magical world the child visits. Keep the environment visible and emotionally dominant. UI should appear as magical objects/panels inside the world and should disappear or soften when not needed.

Use the existing locked child asset already in the project: **boy + Chirpy on his back**. Do not use or add any new boy asset from this pack.

## Asset mapping

Use assets from `reflection_room_assets_v3_no_boy/assets/`:

- `01_reflection_room_background.png` — full-bleed room background. Preserve aspect ratio; crop with cover only when necessary.
- `02_blank_glass_panel_star.png` — dynamic popup/surface for reflection details, monthly insights, or thought constellation.
- `03_blank_glass_panel_heart.png` — affirmation surface / gentle modal / favourite confirmation.
- `04_star_lantern.png` — foreground decorative object with subtle breathing glow.
- `05_crystal_books_garden_vignette.png` — decorative right/left foreground vignette.
- `06_reflection_card_reference.png` — visual reference only; do not rely on baked text.
- `07_monthly_journey_panel_reference.png` — visual reference only; build actual contents dynamically from DB.
- `08_thought_constellation_reference.png` — visual reference only; build actual constellation dynamically.
- `09_compact_story_audio_reference.png` — style reference only. IMPORTANT: do **not** create a long separate audio player bar.
- `10_full_scene_reference.png` — composition reference only.

## Layout

### Base scene
- Full-screen Reflection Room background.
- Existing boy + Chirpy-on-back asset sits low-center/low-left on the meditation rug area.
- Keep the glowing portal visible as the visual destination/focal point.
- Scatter a small number of reflection bricks/stepping stones through the environment. Their text is always rendered from DB in HTML/React, never in the image.
- Each brick is tappable/clickable and represents one saved reflection.

### Header
Top left:
- `Reflection Room ♡`
- small subtitle: `Stay as long as you like.`
- secondary hint: `Tap a glowing reflection to revisit it.`

Keep this lightweight and embedded in the world; no heavy app bar.

### Affirmation focus
The current affirmation should be the main interaction near the child, as a floating magical heart/glass bubble.

Example dynamic copy:
`I am brave, and I keep going.`

Controls should be tiny and integrated into the bubble:
- one small play/pause icon
- favourite heart
- optional repeat icon

Do NOT create a long playback control, timeline, transport strip, or separate audio section.

When audio is playing:
- affirmation bubble gently pulses
- tiny sparkles rise
- portal light subtly breathes
- Chirpy can bob or react if animation infrastructure exists

### Bottom actions
Only 3–4 compact world-native actions:
- `Shuffle a reflection`
- `Breathe and relax`
- `Say it with me`
- optional `Talk to a grown-up`

Keep these small and visually secondary. They can look like glowing plaques or magical stones, not standard rectangular buttons.

## Popups instead of extra screens

Everything extra opens as an elegant in-world popup using the blank glass panel assets. Background remains visible and slightly softens; do not navigate away.

### Popup 1 — Reflection detail
Opened by tapping a reflection brick.
Show dynamic DB fields:
- date
- feeling(s)
- what happened
- old story / thought
- another possible story
- saved affirmation
- optional `Listen` and `Favourite`

Use very short labels. Do not expose raw internal field names.

### Popup 2 — My Journey This Month
Trigger from a small magical star/book object in the room or a small `My month` affordance.
Show only supportive descriptive patterns, never a score of emotional health.

Suggested dynamic data:
- journeys completed this month
- most commonly logged feelings
- number of reflections revisited
- favourite affirmations listened to
- optional gentle trend language such as `You have been practising noticing angry feelings.`

Never label the child as `an angry child`, `an anxious child`, etc.

### Popup 3 — Thought Constellation
Build a real dynamic constellation from DB data.
- each recurring thought/theme is a star
- star size can reflect frequency, but keep range subtle
- connect related themes with faint lines
- tapping a star reveals examples of reflections where it appeared
- show alternative thoughts nearby as smaller differently styled stars

Do not imply the most frequent thought is the most true or important.

## Data rules

Use existing reflection/session database records. Build selectors/derived functions rather than duplicating stored data.

Suggested derived model:

```ts
interface ReflectionRoomSummary {
  journeysThisMonth: number;
  reflectionCount: number;
  mostCommonFeelings: Array<{ label: string; count: number }>;
  commonThoughts: Array<{ label: string; count: number; reflectionIds: string[] }>;
  favouriteAffirmations: Array<{ text: string; playCount: number }>;
  recentReflections: ReflectionRecord[];
}
```

Keep stats descriptive and private to the child. No competitive ranking, streak pressure, grades, or emotional-health score.

## Motion and interaction

Create a calm cinematic idle state:
- lantern light softly flickers
- portal clouds drift extremely slowly
- tiny firefly particles
- crystals shimmer occasionally
- selected reflection brick gets a soft halo
- panels float in by scaling from 0.96 to 1 and fading in
- panel closes with a few sparkles returning into the room

Hover (desktop): slight lift + glow.
Tap/click (all devices): persistent selected state.
Respect `prefers-reduced-motion`.

## Responsive behaviour

Desktop/tablet landscape is the hero composition.
On narrower screens:
- keep child and affirmation visible
- hide nonessential decor first
- reflection bricks can become a horizontally scrollable row of magical stones at the bottom while still feeling part of the room
- popups should become bottom-sheet-like magical panels, but visually remain in-world

## Accessibility

- all tappable objects require real buttons with aria-labels
- minimum ~44px touch targets
- sufficient text contrast over the magical background
- keyboard focus visible
- audio controls expose play/pause state
- do not use hover as the only way to discover content

## Safety/experience constraints

The Reflection Room is a calm, optional space. Never shame, diagnose, or rank feelings. Do not say a thought was `wrong`; show that another story may also fit. `Talk to a grown-up` stays available but visually gentle. If the app already has a quiet/high-distress state, reduce animations, show fewer choices, and make trusted-adult access more prominent.

## Acceptance criteria

1. One integrated Reflection Room, no separate Play & Relax screen.
2. Existing boy + Chirpy-on-back asset only; no new child asset.
3. No long separate audio player.
4. Personalized reflection/affirmation data is live from DB.
5. Reflection details, monthly insights, and thought constellation open as popups in the same scene.
6. Room remains visually dominant; panels are temporary layers.
7. Every visible control works on tap/click and keyboard.
8. Motion is calm and can be reduced.
9. No emotional-health score, judgement, or child labels.
10. Reuse the supplied PNG assets exactly where specified.

Before coding, inspect the existing Reflection Room component, data models, audio helpers, and the locked boy/Chirpy asset path. Reuse project architecture rather than creating parallel systems. Then implement end-to-end in the existing route/component and remove the redundant separate Play & Relax route if it only duplicates this experience.
