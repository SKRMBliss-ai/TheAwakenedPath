# Mind Gym — Story Lab Codex Handoff

This package implements the approved **Story Lab** design.

## Journey architecture

### Already completed before Story Lab
1. Feeling — separate existing room
2. Body — separate existing room

### Story Lab — one persistent room
3. Thought
4. What happened?
5. Story
6. Another way

The child never opens four conventional pages. The same magical room transforms step-by-step.

## Visual source of truth
`approved_reference_story_lab.png`

The exact step compositions are also supplied in `reference_crops/`.

## Implementation assets
`production_assets/` includes:
- clean room/background crops
- boy
- Chirpy
- Story Lab sign
- navigation / grown-up controls
- step icons
- thought bubble group
- buttons
- books / lantern / mug / plant / sign / particle effects

Use these as layered art assets. Render all semantic text and interactive controls in code.

## Critical experience idea
The room should remember what the child said.

Thought becomes a floating thought cloud.
What Happened becomes a memory scene.
Story assembles the collected pieces.
Another Way creates a second possible interpretation next to the first.

This should feel like the child is watching their own mind construct a story.
