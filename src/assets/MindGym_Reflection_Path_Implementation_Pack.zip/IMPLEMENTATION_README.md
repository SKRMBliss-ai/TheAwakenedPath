# Mind Gym — Reflection Path + Reflection Room implementation handoff

## Core interaction

The Reflection Path is a magical path made from tappable reflection bricks. **The PNG brick is deliberately empty. Do not bake words into it.** The application places each child's own reflection/affirmation text over the brick at runtime.

### What happens when the child enters Reflection Room

1. Load the child's saved reflections from their Story Lab / journal history.
2. Randomly sample up to 10 reflections for the visible Reflection Path.
3. Map one saved reflection to each visible brick for that room visit.
4. Render a short child-specific label on the empty brick, e.g. `I can try again`, `Maybe they didn't notice`, `I still belong`, or the child's own approved affirmation.
5. Tapping a brick opens or plays **that mapped reflection**.
6. A fresh sample can be used next time the room is entered, so the path feels magical and different.
7. `My Reflection Library` opens the full archive so nothing is lost and the child can scroll/search/favourite older reflections.
8. `Play one for me` selects a random reflection and immediately starts the calm audio/story playback.

This gives both experiences: **surprise on the path** and **complete control in the archive**.

## Dynamic brick asset

Use:

`assets/bricks/reflection_brick_empty@4x.png`

as the visual background. Overlay the child's text in HTML/React/native UI rather than editing the PNG.

Recommended overlay rules:

- centered horizontally and vertically
- 2–3 lines maximum on the path
- short label derived from the saved new story / affirmation
- high contrast dark-violet text
- responsive font sizing
- do not rasterize child text into the image
- full reflection text belongs in the playback/detail view, not on the path brick

Pseudo-structure:

```tsx
<button className="reflection-brick" onClick={() => openReflection(reflection.id)}>
  <img src="/assets/bricks/reflection_brick_empty@4x.png" alt="" />
  <span className="reflection-brick__label">{reflection.pathLabel}</span>
</button>
```

## Suggested reflection record

Use the app's existing session/journal storage as the source of truth. A derived reflection record can contain:

```ts
type ReflectionRecord = {
  id: string
  sourceSessionId: string
  createdAt: string
  feeling?: string
  body?: string
  thought?: string
  whatHappened?: string
  originalStory?: string
  anotherWay?: string
  affirmation?: string
  pathLabel: string
  favourite?: boolean
  timesPlayed?: number
}
```

Do not overwrite the child's original story when a new perspective is created; keep both.

## Path selection logic

On entry:

```ts
const pool = allReflectionsForChild
const visible = sampleWithoutReplacement(pool, Math.min(pool.length, 10))
```

Prefer not to repeat the exact same visible set on consecutive visits. Favourites may be weighted slightly more often, but still keep variety.

If there are no reflections yet, keep the magical path visible but show a gentle message leading back to Story Lab. Do not invent reflections for the child.

## Tapping a brick

A brick should:

- glow on hover/focus/touch-down
- rise slightly
- emit a few sparkles
- open a reflection bubble/card or transition into Play & Relax mode
- play the saved story/affirmation with the room's calm music if audio is enabled

Use `reflection_brick_hover@4x.png` for hover/active state if desired.

## Full archive / Reflection Library

The archive is separate from the magical path. It should support:

- all reflections
- recent
- favourites
- simple themes such as brave / calm / kind / belonging / try again
- scrollable history
- replay
- favourite/unfavourite

Avoid making the path itself an endless scrolling grid. The path is the magical discovery layer; the library is the archive.

## Visual continuity

Use the PNGs in `reference_scenes/` as composition references. Keep the child, Chirpy, lanterns, warm amber light, violet magic, plants, wood, twilight sky and soft cinematic 3D language consistent with the approved Mind Gym world.

## Important child-safety/product rules

- Reflections are not scored as right/wrong.
- Do not tell the child their old story was "wrong".
- Present the new story as another possible way of looking at what happened.
- Let the child stop, mute, or leave the room at any time.
- Do not generate a personal affirmation that claims certainty about facts the child cannot know.
- Keep body and emotional language gentle and non-diagnostic.

## Files

- `reference_scenes/` — approved full-scene designs
- `assets/bricks/` — empty, hover, completed and locked brick states
- `assets/characters/` — child + Chirpy cutouts
- `assets/decor/` — room props
- `assets/effects/` — magic particles/effects
- `source_sheets/` — original generated visual asset sheets
- `manifest.json` — asset/package metadata
