# Mind Gym — Closed-Door Home / My Good Choices — Codex Handoff

## Approved home architecture

### Left
**Funny Feeling?**
- keep the approved glowing blue portal/panel
- this starts the emotional journey

### Centre
- use the **usual existing Mind Gym boy**
- Chirpy stays with/on the boy
- do not replace the character with a new interpretation

### Right
**My Good Choices**
- seven magical rooms built into a wooden shelf
- all room doors are CLOSED at rest
- the child discovers the content by interacting with a door

Rooms:
1. Be Kind
2. Tell the Truth
3. Make Good Choices
4. Include Everyone
5. Take Care of My Body
6. Help Others
7. Mind & Heart Time

## Door interaction

### Desktop / mouse / trackpad
1. hover or keyboard-focus a room
2. room sign glows
3. tiny star/keyhole lights
4. door rotates open slightly
5. interior illustration becomes visible
6. compact prompt + `Play` / `Learn` controls appear
7. moving away closes it gently unless the child clicked/pinned it

### Touch
There is no hover:
1. first tap opens the room
2. show the prompt + Play/Learn
3. second tap on an action enters that experience
4. tapping another room closes the previous one

Only one room should be open at a time.

## Assets

`production_assets/`
contains clean separated art from the established Mind Gym visual set, including:
- boy
- Chirpy
- Mind Gym logo
- feelings art
- Good Choices room art
- category signs
- buttons
- points/month badges
- clean environment background

`reference_crops/`
contains exact crops from:
- the approved closed-door design
- the older open-room design used as the interaction-state reference

The approved closed-door image is the visual source of truth for the resting home state.
The open reference is the behavioural source of truth for what appears after a door opens.

## Important

Do not build the screen as a single static background screenshot.
Use layered imagery and real UI controls so hover, focus, tap, accessibility, responsive layout and animation work properly.
