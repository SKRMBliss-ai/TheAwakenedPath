# CLAUDE CODE IMPLEMENTATION PROMPT
## Mind Gym — Reflection Room V4

You are implementing the **Reflection Room** for the children's Mind Gym application.

IMPORTANT: This is **one integrated magical room**, not two separate screens and not a dashboard-first UI.

The child comes here to:
- relax
- revisit past reflections
- listen to personalised affirmations from their own journeys
- breathe for a short calming exercise
- do a two-minute quiet meditation
- gently look back at patterns from the last month

All historical content already exists in the database.

### PRODUCT RULES

1. DO NOT create a separate "Play & Relax" page.
2. DO NOT use the long horizontal audio player from the old design.
3. DO NOT add a new boy illustration. Use the project's existing locked **boy + Chirpy-on-back** asset.
4. Keep everything in the same Reflection Room environment.
5. Reflection data, thoughts, feelings, journeys and affirmations must come from the existing database.
6. No scores for emotional health. Stats describe practice only.
7. Never label a feeling or thought as wrong.
8. "Talk to a grown-up" remains available but visually quiet.
9. The room must feel calm, magical and explorable — not like analytics software.
10. Respect the project Quiet State rules. When high-distress mode is active, hide monthly pattern analytics and disable clever/complex interactions.

---

# ASSETS

Use these files from the supplied asset folder:

## Reflection bricks
- `reflection_brick_empty.png`
- `reflection_brick_hover.png`
- `reflection_brick_selected.png`
- `reflection_brick_completed.png`

IMPORTANT:
These are visual backgrounds only.
Render the child's database text as live HTML/text OVER the brick.
Do NOT bake personalised reflection copy into PNGs.

## Thought bubble
- `thought_box_blank.png`

Use this for the child's thought/old-story popup.
Render all thought text dynamically.
The thought cloud should float above the selected reflection brick and gently bob.

## Breathing
- `breathing_orb_idle.png`
- `breathing_orb_inhale.png`
- `breathing_orb_exhale.png`

## Meditation
- `meditation_focus_star.png`

## Affirmation
- `affirmation_bar_blank.png`

## Existing room references/decor
Use the supplied background/decor/reference PNGs where appropriate.
Do not replace the existing boy + Chirpy asset in the repository.

---

# DESKTOP COMPOSITION

The Reflection Room remains a single continuous 16:9 scene.

### Center
Use the existing boy + Chirpy-on-back artwork on the central rug.

Behind them:
- reflection portal
- steps/path
- reflection bricks placed physically in the world

The room should visually breathe. Do not cover the background with large permanent cards.

### Reflection bricks
Show approximately 5–9 nearby bricks depending on viewport.

Each brick represents one saved reflection.

Default:
- warm low glow
- short reflection title only

Hover/focus:
- use `reflection_brick_hover.png`
- slight lift: translateY(-6px)
- warm light bloom
- tiny sparkle particles
- title becomes a little brighter

Selected:
- use `reflection_brick_selected.png`
- nearby world slightly dims
- open one compact magical reflection card / thought bubble
- never navigate to another page

Completed/favourite:
- use `reflection_brick_completed.png`

### Reflection detail
When a brick is tapped, reveal only the useful current reflection:

Event → old story → another possible story → affirmation.

Do NOT immediately show every field.

Use small magical reveal affordances:
- tap the thought cloud to reveal the old story
- tap a leaf/star to reveal "another way"
- tap the heart to hear the affirmation

Extra data should feel discovered, not displayed as a form.

---

# COMPACT AFFIRMATION PLAYBACK

REMOVE the long music-player bar.

Instead, the main affirmation should appear in a compact glowing pill over the rug:

`affirmation_bar_blank.png`

Dynamic text example:
"I am brave, and I keep going."

Controls should be tiny and integrated:
- speaker icon: play/pause
- heart: favourite
- shuffle sparkle: another saved affirmation

When playing:
- pill glows softly
- stars drift upward
- Chirpy does a tiny listening/breathing animation
- spoken affirmation can repeat once if the child chooses

Never show a scrubber/progress timeline for a single short affirmation.

---

# BREATHING EXPERIENCE — WORLD TRANSFORMATION, NOT POPUP SCREEN

Trigger:
Child taps **Breathe & Relax**.

Do NOT open a new route.

Transition the room into `calmMode = "breathing"`:

1. UI analytics softly fade to 20% opacity.
2. Reflection bricks dim.
3. Lanterns become slightly warmer.
4. Background motion slows.
5. A breathing orb rises from the rug in front of the child.
6. Use:
   - `breathing_orb_idle.png`
   - crossfade/scale to `breathing_orb_inhale.png`
   - crossfade/scale to `breathing_orb_exhale.png`

### Breathing rhythm
Use a simple child-friendly pattern:
- inhale 4 seconds
- exhale 6 seconds
- no breath-hold by default

Do not force exact timing.
The visual invitation is:
- orb expands = breathe in
- orb becomes smaller = breathe out

On-screen copy is minimal:
"Breathe in…"
"Breathe out…"

A small secondary action:
"Stop whenever you like"

Default short breathing session:
60 seconds.

After completion:
- orb turns into 3–5 tiny stars
- stars return into the portal/rug
- room restores gently
- no "success" score
- optional line: "Stay here as long as you like."

Respect `prefers-reduced-motion`.

---

# TWO-MINUTE MEDITATION — "QUIET STAR"

Add a compact world action:
**2 min quiet**

Do NOT make this a conventional meditation player.

When tapped:
set `calmMode = "meditation"`.

### Scene change
- boy + Chirpy remain visible
- room becomes slightly darker and softer
- analytics and reflection texts fade away
- `meditation_focus_star.png` appears above the rug
- star floats very slowly
- ambient particles reduce substantially
- lantern flicker slows

### Opening narration
Optional, one sentence only:
"Watch the little star, or just rest here."

Then silence.

No questionnaire.
No instructions every few seconds.
No progress bar.

### Time
Run for 120 seconds.

Represent time spatially:
- 12 tiny fireflies/stars around the rug
- one softly disappears every 10 seconds
OR
- the star's halo completes one slow circular orbit over 2 minutes

Do not display `01:34` countdown by default.

Child can always tap:
"Finish for now"

### End
At 2 minutes:
- star gives one gentle warm pulse
- Chirpy opens eyes / lifts head
- room slowly restores
- optional affirmation is spoken once
- no confetti
- no badge
- no "you did it!" pressure

---

# MONTHLY JOURNEY DATA

Monthly patterns should NOT permanently dominate the room.

Place one magical object such as a hanging constellation lantern / small star panel labelled:
**My month**

Tap opens a compact floating panel containing database-derived data:
- number of reflection journeys completed this month
- most common feelings
- recurring thought themes

Examples:
12 journeys
Angry · Sad · Worried · Excited
Common thought: "They don't like me."

Use descriptive phrasing only.
Never say:
"You are an angry child"
"You worry too much"
"Your emotional score..."

### Thought constellation
The "most common thoughts" view should appear as a constellation:
- each recurring thought theme = one star
- frequency changes star size slightly
- connecting lines are decorative, not diagnostic
- tapping a star shows examples from the child's saved reflections

Include:
"These are thoughts you've noticed — not facts about you."

---

# DATA MODEL / BINDING

Adapt to the existing project schema. Do not duplicate data.

Expected derived selectors:

```ts
type ReflectionSummary = {
  id: string;
  date: string;
  feeling?: string;
  event?: string;
  oldStory?: string;
  alternativeStory?: string;
  affirmation?: string;
  favourite?: boolean;
};

type ReflectionMonthSummary = {
  journeyCount: number;
  feelingCounts: Array<{ label: string; count: number }>;
  thoughtThemes: Array<{
    label: string;
    count: number;
    reflectionIds: string[];
  }>;
};
```

Create selectors, not new permanent duplicated records:

```ts
getRecentReflections(childId)
getMonthlyReflectionSummary(childId, month)
getSavedAffirmations(childId)
getFavouriteAffirmations(childId)
```

For "common thoughts", use the project's existing thought/theme categorisation if available.
Do not invent psychological labels.

---

# COMPONENT ARCHITECTURE

Suggested:

```txt
ReflectionRoom
 ├─ ReflectionEnvironment
 │   ├─ ExistingBoyAndChirpy
 │   ├─ ReflectionPortal
 │   ├─ ReflectionPath
 │   │   └─ ReflectionBrick[]
 │   └─ AmbientRoomDecor
 │
 ├─ SelectedReflectionReveal
 │   ├─ ThoughtCloud
 │   ├─ AlternateStoryReveal
 │   └─ CompactAffirmation
 │
 ├─ CalmExperienceLayer
 │   ├─ BreathingOrb
 │   └─ QuietStarMeditation
 │
 ├─ MonthObject
 │   └─ MonthlyJourneyPopover
 │       ├─ JourneyCount
 │       ├─ FeelingGarden
 │       └─ ThoughtConstellation
 │
 └─ SafetyActions
     └─ TalkToGrownUp
```

Do not make `Breathing` and `Meditation` full routes unless the existing routing architecture absolutely requires it.
Visually they remain in the room.

---

# ANIMATION SPEC

### Reflection bricks
idle:
- tiny glow breathing 4–6s
- no constant bouncing

hover:
- lift 6px
- glow increase
- 250–350ms ease-out

tap:
- short light ripple through neighbouring stones

### Thought cloud
- 3–5px gentle vertical drift
- 5s cycle
- stop/reduce if reduced-motion

### Breathing orb
inhale:
- scale ~0.78 → 1.0 over 4s
- halo brightens

exhale:
- scale 1.0 → 0.70 over 6s
- halo softens

### Meditation star
- almost still
- tiny 1–2% breathing glow only
- no distracting sparkle storm

### Room
During calm modes:
- freeze nonessential hover effects
- reduce particle count
- disable shuffle/analytics until calm mode ends

---

# AUDIO

Use the app's existing audio system.

Breathing:
- optional quiet bell at start/end only
- no bell every breath

Meditation:
- subtle room ambience
- no constant voice guidance
- optional opening sentence + ending affirmation

Affirmations:
- use personalised stored affirmation text
- use existing narration/TTS pipeline if available

Never autoplay loud audio.

---

# RESPONSIVE

Desktop:
- world-first landscape composition

Tablet:
- same world composition, fewer visible reflection bricks

Mobile:
- keep the environment
- show 3–5 bricks in a horizontal curved path
- month popup becomes a bottom magical sheet
- breathing orb remains centered
- meditation star remains centered

Do not collapse the mobile version into a plain card list.

---

# ACCESSIBILITY

- All image buttons need accessible labels.
- Every hover interaction must work by tap/focus.
- Reflection bricks are real buttons.
- Keyboard focus gets a visible glow.
- Use `aria-live="polite"` for breathing text only.
- Do not force animation.
- "Stop whenever you like" remains available in both calm modes.

---

# ACCEPTANCE CRITERIA

The implementation is correct when:

- Reflection and relax experiences are in ONE room.
- The existing boy + Chirpy asset is reused.
- Reflection bricks are dynamic and database-driven.
- Brick PNGs contain NO personalised text.
- Thought cloud PNG contains NO text.
- Long audio player is gone.
- Affirmations play through a compact integrated control.
- Breathing happens by transforming the room.
- Two-minute meditation happens in the same room.
- Monthly journey data is available through magical popovers.
- Thought themes are shown as observations, never diagnoses.
- High-distress Quiet State simplifies the experience.
- The child can leave/stop at any time.
- It feels like an explorable magical resting place, not a wellbeing dashboard.
