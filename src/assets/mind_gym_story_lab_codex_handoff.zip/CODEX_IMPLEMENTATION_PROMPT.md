# CODEX IMPLEMENTATION PROMPT
## Mind Gym — Story Lab, one-room flow for Steps 3–6

You are implementing the approved **Story Lab** interaction shown in this handoff.

Read first:
1. `README_START_HERE.md`
2. `manifest.json`
3. `approved_reference_story_lab.png`
4. all images in `reference_crops/`
5. inspect the existing repo before changing anything

The approved design is the source of truth. Do not replace it with a generic card wizard.

# PRODUCT ARCHITECTURE

Feeling and Body have ALREADY been designed as separate rooms and should remain separate.

The journey is:

1. Feeling — existing room
2. Body — existing room
3. Thought — Story Lab
4. What happened? — Story Lab
5. Story — Story Lab
6. Another way — Story Lab

The Story Lab is ONE persistent magical room containing steps 3–6.

There must be NO page refresh, hard route cut, or conventional multi-page questionnaire between these four Story Lab steps.

The child should feel:
“I entered Story Lab and watched my thoughts turn into a story.”

Not:
“I answered four forms.”

# STORY LAB SCENE

Maintain the approved warm magical treehouse room:
- deep violet / plum shadows
- warm amber lantern light
- rounded wooden architecture
- plants and vines
- cozy books
- glowing magic
- night window / moon outside
- purple floor rug
- child-friendly cinematic depth
- same Mind Gym art direction
- Chirpy physically present in the room

Persistent controls:
- back
- Mind Gym logo
- Talk to a grown-up

Story Lab title:
**Story Lab**
Subtitle:
**Explore your mind. Find new perspectives.**

# LAYOUT

Desktop / tablet:

LEFT RAIL, ~20%
- compact journey map
- Step 1 Feeling = completed
- Step 2 Body = completed
- Step 3 Thought
- Step 4 What happened?
- Step 5 Story
- Step 6 Another way
- only current Story Lab step glows strongly
- completed steps have a small check / glow
- future steps are dim, not disabled-looking

CENTER, ~55–60%
- active interactive experience
- this is the main visual theatre
- each step uses the same physical room but changes the magical content in the centre

RIGHT / LOWER-RIGHT, ~20–25%
- Chirpy
- one short supportive bubble
- do not use a chatbot transcript

BOTTOM
- optional compact progress connector
- avoid large footer navigation if the room transition itself can communicate progress

# CARRIED STATE FROM PREVIOUS ROOMS

Story Lab receives:
- selected feeling(s)
- selected body region(s)
- age band / reading level
- quiet state
- session id

Do not ask Feeling and Body again.

Show them only as small collected memory tokens when helpful.

Example:
small pink heart orb = “Sad”
small teal body token = “Tight chest”

# TRANSITION INTO STORY LAB

From Body Room:
1. child completes body selection
2. room door / portal glows
3. Chirpy leads the child toward Story Lab
4. use a short cinematic transition
5. Story Lab opens with the child’s Feeling + Body already represented as two small glowing tokens
6. Step 3 Thought becomes active

No loading-screen feeling.

# STEP 3 — THOUGHT

Current-step theme:
soft purple / lavender / blue-white cloud magic

Chirpy says:
**“What was your mind saying?”**

Supporting line:
**“Tap a thought, or tell me in your own words.”**

The centre of the room fills with 4–6 floating thought clouds.

Possible neutral starter thoughts:
- “I can’t do it.”
- “They don’t like me.”
- “It’s not fair.”
- “What if…?”
- “I’m not sure.”

Also provide:
**Say it your way**
using speech input if the repo already supports voice.

For older children:
also permit text.

Interaction:
- thought clouds drift gently
- hovered/focused cloud floats slightly forward
- selected cloud glows and moves toward the child’s growing Story Trail
- if the child speaks/types, render the child’s own words in a new cloud
- allow “I’m not sure”

Do not mark thoughts correct or incorrect.

Once captured:
- the Thought cloud becomes a small persistent clue in the room
- light travels from Step 3 to Step 4
- the room does NOT change page

# STEP 4 — WHAT HAPPENED?

Theme:
warm cinema / memory magic

Chirpy:
**“What actually happened?”**

Younger-child helper:
**“What would a little camera have seen?”**

The room’s centre transforms into a miniature memory theatre / framed scene.

Show 4–6 optional event starters around the miniature scene:
- Someone said something
- I had to wait
- I didn’t get to join
- I made a mistake
- Something changed
- Something else

Also:
**Tell it in your own words**

The event needs to stay concrete and observable.

Do not force detail.
Do not interrogate.
A short answer is enough.

When selected:
- the memory scene freezes like a tiny magical film frame
- it becomes the Event clue
- the Thought clue remains visible nearby
- a ribbon of light connects Event → Thought
- Step 5 begins

# STEP 5 — STORY
## HIGHEST-IMPACT MOMENT

This is the visual hinge and must receive the most attention.

Chirpy:
**“Here’s the story your mind made…”**

Do NOT immediately ask another question.

Instead visually assemble the child’s previously collected pieces.

Bring into the central space:
- Feeling token from Room 1
- Body token from Room 2
- Thought cloud from Step 3
- What Happened memory frame from Step 4

They orbit gently around a glowing sphere / open magical book.

Golden / violet light connects them.

Then a larger Story object is created.

Example:

WHAT HAPPENED:
“I didn’t get to join.”

THOUGHT:
“They don’t like me.”

FEELING:
Sad

BODY:
Tight chest

STORY MY MIND MADE:
“They don’t want me to be part of it.”

Use careful framing:
the app is displaying a story the mind formed, not declaring that story false.

Ask:
**“Does this sound like what your mind was saying?”**

Choices:
- Yes
- Almost
- Change it
- Not sure

If “Almost” or “Change it”:
allow the child to edit/say their own story.

After confirmation:
the Story object moves into the Story Trail.
The room lighting subtly shifts.
A second path begins to glow.

# STEP 6 — ANOTHER WAY

Theme:
aqua / gold / fresh possibility light

Chirpy:
**“Could anything else be true?”**

Subtitle:
**“Let’s explore some other possible stories.”**

The SAME event remains visible.

Do not replace the original Story.

Instead split the visual stage into two magical windows:

LEFT:
**Original Story**
shows what the mind first made.

RIGHT:
**Another Possibility**
starts empty / glowing.

Around the stage show 3–4 gentle possibilities, context-sensitive if existing content infrastructure supports it.

Examples:
- “Maybe it only happened this time.”
- “Maybe they were busy with something else.”
- “Maybe I can try again in a different way.”
- “My own idea…”

The child can choose one OR speak/type their own.

When chosen:
the second window fills with that possibility.

Important:
Do NOT say the alternative is the truth.
Use language such as:
- “Another possibility”
- “Something else that could be true”
- “Another way to look at it”

Never:
- “Correct answer”
- “Better thought”
- “Wrong story”

# END STATE

Do not add a new seventh reflection step.

After Another Way:
- all four Story Lab markers glow
- small Feeling and Body tokens remain visible as the first two completed journey pieces
- show one beautiful final constellation / path:

Feeling
→ Body
→ Thought
→ What Happened
→ Story
↘ Another Way

Chirpy:
**“Look at everything you noticed.”**

Primary action:
**Save This Journey** if session saving already exists.

Secondary:
**Back to Mind Gym**

Do not award points for choosing a more positive interpretation.

# ROOM-MEMORY PRINCIPLE

This is critical.

Every answer should physically remain in the room in compact form.

At Step 3:
Feeling + Body tokens exist.

At Step 4:
Feeling + Body + Thought.

At Step 5:
Feeling + Body + Thought + Event assemble.

At Step 6:
Original Story remains visible while Another Possibility is added.

Nothing should feel discarded between steps.

# MOTION

Use restrained cinematic motion.

Suggested durations:
- hover/focus: 150–220ms
- step activation: 350–500ms
- answer moving into Story Trail: 500–700ms
- Story assembly: 900–1400ms
- original story → second possibility branching: 700–1100ms

Motion vocabulary:
- soft float
- small scale-forward
- light ribbon
- orbit
- book opening
- cloud forming
- magical frame appearing
- path branching

Avoid:
- bouncing everything
- huge particle explosions
- confetti
- rapid pulsing
- overstimulation

# CHIRPY

Chirpy is a spatial guide, not a chat interface.

Keep speech extremely short.

Thought:
“What was your mind saying?”

Event:
“What actually happened?”

Story:
“Your mind made a story from those pieces.”

Another Way:
“Could anything else be true?”

Use character animation:
- glance toward active object
- tiny hop
- head tilt
- small wing gesture
- soft idle breathing

# MOBILE

Do not shrink the desktop composition.

On mobile:
- top = Story Lab + progress `3 of 6`
- middle = active experience
- bottom = Chirpy + short bubble
- completed Story Lab clues become small horizontally scrollable glowing chips
- step rail collapses into 4 dots for Thought → Event → Story → Another Way
- Feeling and Body show as two tiny completed icons before the four Story Lab dots

Only ONE main interaction should dominate the viewport.

# ACCESSIBILITY

- real semantic buttons
- visible focus states
- descriptive accessible names
- large tap targets
- voice must never be the only input
- text alternatives for imagery
- animation respects reduced-motion preferences
- do not rely on colour alone for step state
- all baked text shown in PNG reference assets must be rebuilt as real HTML/UI text

# QUIET STATE

If quiet/high-distress mode is active:
- reduce animation
- remove playful flourishes
- display max 3 options + “I’m not sure”
- short prompts
- larger targets
- grown-up action more prominent
- child can stop without completing the Story Lab

# DATA MODEL

Use the repo’s existing session model when possible.

Conceptually Story Lab needs:

storyLab: {
  carriedFeelingIds: string[],
  carriedBodyRegions: string[],
  thought: {
    text?: string,
    starterId?: string,
    inputMode?: "choice" | "voice" | "text"
  },
  event: {
    text?: string,
    starterId?: string,
    inputMode?: "choice" | "voice" | "text"
  },
  story: {
    text: string,
    confirmed: boolean
  },
  alternatives: Array<{
    text: string,
    source?: "suggested" | "child"
  }>,
  currentStep: "thought" | "event" | "story" | "anotherWay" | "complete"
}

Adapt to existing repo conventions.

# COMPONENT ARCHITECTURE

Prefer reusable components, names adjusted to repo style:

StoryLabRoom
StoryLabJourneyRail
StoryLabStage
CollectedClueTrail
ChirpyGuide

ThoughtStep
EventStep
StoryAssemblyStep
AnotherWayStep

ThoughtCloud
MiniMemoryTheatre
StoryOrb
PossibilityWindow
MagicalConnectionRibbon

Do not make four unrelated route components.

# ART ASSETS

Use:
`production_assets/background_story_lab.png`
as the scene/background basis when appropriate.

Use layered assets for:
- boy
- Chirpy
- Story Lab sign
- back / grown-up controls
- thought cloud art
- step icons
- books / lantern / plant / mug / decorative sign
- subtle stars/particles

The files in `reference_crops/` show exact approved composition per step.

The approved reference:
`approved_reference_story_lab.png`
is the final visual source of truth.

IMPORTANT:
The generated PNGs are implementation art / reference layers.
Do not bake the whole UI into a single screenshot.
Keep text, buttons, answers and stateful elements in code.

# REPO INTEGRATION PROCEDURE

Before coding:
1. inspect routes
2. inspect existing Feeling Room completion state
3. inspect existing Body Room completion state
4. inspect session store
5. inspect Chirpy component/assets
6. inspect voice input
7. inspect quiet state
8. inspect trusted-grown-up control
9. inspect animations/design tokens
10. find existing reusable input/card components

Reuse existing infrastructure.

Do not rebuild working Feeling or Body Rooms.

# ACCEPTANCE TESTS

Implementation is accepted when:

- Feeling is still a separate existing room
- Body is still a separate existing room
- Body completion naturally enters Story Lab
- Story Lab contains Steps 3–6 only
- Steps 3–6 happen inside ONE persistent room
- no conventional page wizard is introduced
- Thought supports choice + own words
- Event is framed as observable “what happened”
- Story visibly assembles collected pieces
- child can edit/confirm the Story
- Another Way preserves Original Story and adds a second possibility
- alternative is never presented as definite truth
- previous clues persist visually
- Chirpy remains concise and supportive
- trusted-grown-up remains accessible
- mobile is intentionally recomposed
- reduced-motion / quiet state works
- all interactive text is real UI text
- typecheck passes
- lint passes
- tests pass
- production build passes

After finishing, report:
1. files changed
2. components created/reused
3. route changes
4. state/data changes
5. transition/animation work
6. mobile work
7. accessibility work
8. tests/build results
9. anything intentionally left unchanged
